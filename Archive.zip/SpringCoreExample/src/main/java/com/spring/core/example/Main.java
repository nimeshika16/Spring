package com.spring.core.example;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	
	private static ApplicationContext context;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		/* ApplicationContext context = new ClassPathXmlApplicationContext("bean.xml");
		HelloWorld hello = (HelloWorld) context.getBean("HelloWorld");
		hello.sayName();
		*/ 
		
		// loading the definitions from the given XML file
				ApplicationContext context = new ClassPathXmlApplicationContext(
						"applicationContext.xml");
		 
				HelloWorld service = (HelloWorld) context.getBean("helloWorldService");
				String message = service.sayHello();
				System.out.println(message);
		 
				//set a new name
				service.setName("Spring");
				message = service.sayHello();
				System.out.println(message);
		
	}

}
