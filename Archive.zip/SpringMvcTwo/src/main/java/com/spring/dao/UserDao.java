package com.spring.dao;

import com.spring.model.Login;
import com.spring.model.User;

public interface UserDao {
	
  int Register1(User user);
  User ValidateUser1(Login login);

  
}