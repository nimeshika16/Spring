package com.spring.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.spring.dao.UserDao;
import com.spring.model.Login;
import com.spring.model.User;


public class UserServiceImpl implements UserService {

  @Autowired
  public UserDao userDao;

  public int Register1(User user) {
    return User.Register1(user);
  }

  public User ValidateUser1(Login login) {
    return userDao.ValidateUser1(login);
  }

}