package com.spring.service;

import com.spring.model.Login;
import com.spring.model.User;

public interface UserService {
	
	  int Register1(User user);
	  User ValidateUser1(Login login);

}
