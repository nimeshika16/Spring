package com.spring.test;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.spring.model.Login;
import com.spring.model.User;



@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = { "classpath:com/spring/config/user-beans.xml" })
public class UserServiceTest {

  @Autowired
  private UserServiceTest userService;

  @Test
  public void testRegister() {
    User user = new User();
    user.setUsername("ranjith");
    user.setPassword("sekar");
    user.setFirstname("Ranjith");
    user.setLastname("Sekar");
    user.setAddress("chennai, t.nagar");
    user.setEmail("ranjith@gmail.com");
    user.setPhone(222);

    int result = userService.Register1(user);
    Assert.assertEquals(1, result);
  }


private int Register1(User user) {
	// TODO Auto-generated method stub
	return 0;
}


@Test
  public void testValidateUser() {
    Login login = new Login();
    login.setUsername("ranjith");
    login.setPassword("sekar");

    User user = userService.ValidateUser1(login);
    Assert.assertEquals("Ranjith", user.getFirstname());
  }


private User ValidateUser1(Login login) {
	// TODO Auto-generated method stub
	return null;
}


}